clc; close all; clear all;
global den;
global num;
global gamma;

zeta = 0.7;
wn = 1;
obs = 2;

Am = [1 2*zeta*wn wn^2];
A0 = [1 obs]

den = conv(Am, A0);
num = [wn^2*obs];
gamma = 1;